package com.example.hariprasad.androidactivitycycle;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private static Button button_b;
    private static Button dialog_button;
    int counter;
    private String value;
    private static EditText counter_value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        onClickDialog();
        onClickActivity();
    }
    public void closeapp(View view){
        finish();
    }
    public void onClickActivity(){
        button_b = (Button)findViewById(R.id.activity_button);
        button_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent activity_b = new Intent(MainActivity.this,ActivityB.class);
                startActivity(activity_b);
            }
        });
    }
    public void onClickDialog(){
        dialog_button = (Button)findViewById(R.id.dialog_button);
        dialog_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent dialog = new Intent("com.example.hariprasad.androidactivitycycle.Dialog_Activity");
                startActivity(dialog);

               /* AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setMessage("DialogBox").setNegativeButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = dialog.create();
                alert.setTitle("Dialog Box");
                alert.show(); */
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    protected void onResume() {
       super.onResume();
        counter++;
        value = Integer.toString(counter);
        counter_value = (EditText)findViewById(R.id.counter_field);
        counter_value.setText(value);
    }

}
